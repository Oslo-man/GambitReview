var moveNumber = 1;

var g_allMoves = [];
var g_playerWhite = true;
var g_changingFen = false;
var g_analyzing = false;

var g_uiBoard;

// Engine level: 1=Beginner, 2=Training, 3=Serious
var g_engineLevel = 3;

// Engine file per level
var g_engineFiles = {
    1: "js/fahriengine1.js",
    2: "js/fahriengine2.js",
    3: "js/fahriengine.js"
};

// Engine name & sub info per level
var g_engineInfo = {
    1: { name: "Fahri mengajar", sub: "1200+ Elo" },
    2: { name: "Fahri tidak fokus", sub: "1900+ Elo" },
    3: { name: "Fahri serius",  sub: "2200+ Elo" }
};

// Board cell size calculated dynamically from screen width
var g_cellSize = 44; // recalculated by RecalcCellSize() once the layout is in the DOM

function RecalcCellSize() {
    var wrapper = document.querySelector('.board-wrapper');
    var evalBar = document.getElementById('evalBarContainer');
    var availW = window.innerWidth - 16;
    var availH = window.innerHeight - 16;

    if (wrapper) {
        var rect = wrapper.getBoundingClientRect();
        if (rect.width > 10)  availW = rect.width;
        if (rect.height > 10) availH = rect.height;
    }

    var evalBarW = (evalBar && evalBar.style.display !== 'none') ? 20 : 0;
    availW = availW - evalBarW - 6;

    var size = Math.floor(Math.min(availW, availH) / 8);
    g_cellSize = Math.max(28, Math.min(64, size));
    return g_cellSize;
}

// Mode: 'friendly' or 'challenge'
var g_mode = 'friendly';

// Sound on/off (used by the sound engine below)
var g_soundEnabled = true;

// Currently selected square in UI space ({x,y}, 0-7) or null
var g_selectedSquare = null;

// Legal destination squares (UI space) for the currently selected piece
var g_legalTargets = [];

// True once the current game has ended (checkmate/stalemate)
var g_gameOver = false;

// ── SETTINGS PANEL ────────────────────────────────────────────────────────────
function UIOpenSettings() {
    var modal = document.getElementById('settingsModal');
    if (modal) modal.style.display = 'flex';
}

function UICloseSettings() {
    var modal = document.getElementById('settingsModal');
    if (modal) modal.style.display = 'none';
}

// ── CHANGE LEVEL ──────────────────────────────────────────────────────────────
function UIChangeLevel() {
    var sel = document.getElementById("LevelSelect");
    g_engineLevel = parseInt(sel.value, 10);

    var info = g_engineInfo[g_engineLevel];
    var nameEl = document.getElementById("engineName");
    var subEl  = document.getElementById("engineSub");
    if (nameEl) nameEl.textContent = info.name;
    if (subEl)  subEl.textContent  = info.sub;

    if (g_backgroundEngine != null) {
        g_backgroundEngine.terminate();
        g_backgroundEngine = null;
    }
    g_backgroundEngineValid = true;
    ResetEvalEngine();
    UpdateTimeRowVisibility();
    UINewGame();
}

// Waktu per gerakan is only relevant for Level 3, and only in Mode Dengan Alat
function UpdateTimeRowVisibility() {
    var timeRow = document.getElementById('timeRow');
    if (!timeRow) return;
    var show = (g_mode === 'friendly') && (g_engineLevel === 3);
    timeRow.style.display = show ? 'flex' : 'none';
}

// ── CHANGE MODE (called from dropdown) ───────────────────────────────────────
function UISetModeFromSelect() {
    var sel = document.getElementById("ModeSelect");
    UISetMode(sel.value);
}

// ── CHANGE MODE ───────────────────────────────────────────────────────────────
function UISetMode(mode) {
    if (!confirm("Apakah Anda yakin?")) {
        // Revert select to current mode if user cancels
        var sel = document.getElementById("ModeSelect");
        if (sel) sel.value = g_mode;
        return;
    }

    g_mode = mode;

    // Sync dropdown in case called programmatically
    var sel = document.getElementById("ModeSelect");
    if (sel) sel.value = mode;

    var btnUndo    = document.getElementById('btnUndo');
    var statusBar  = document.getElementById('output');
    var fenSection = document.getElementById('fenSection');
    var evalBar    = document.getElementById('evalBarContainer');

    var show = (mode === 'friendly');
    if (btnUndo)    btnUndo.style.display    = show ? 'flex' : 'none';
    if (statusBar)  statusBar.style.display  = show ? 'block' : 'none';
    if (fenSection) fenSection.style.display = show ? 'block' : 'none';
    if (evalBar)    evalBar.style.display    = show ? 'flex' : 'none';
    UpdateTimeRowVisibility();

    if (mode === 'challenge') {
        document.body.classList.add('mode-challenge');
    } else {
        document.body.classList.remove('mode-challenge');
    }

    if (mode === 'challenge' && g_analyzing) {
        UIAnalyzeToggle();
    }

    UINewGame();
}

// ── NEW GAME (from button, with confirmation) ─────────────────────────────────
function UINewGameConfirm() {
    if (!confirm("Apakah Anda yakin?")) return;
    UINewGame();
}

// ── NEW GAME (internal, no confirmation) ──────────────────────────────────────
function UINewGame() {
    moveNumber = 1;
    g_selectedSquare = null;
    g_legalTargets = [];
    g_gameOver = false;
    UICloseGameOverDialog();

    var pgnTextBox = document.getElementById("PgnTextBox");
    pgnTextBox.value = "";

    EnsureAnalysisStopped();
    ResetGame();
    if (InitializeBackgroundEngine()) {
        g_backgroundEngine.postMessage("go");
    }
    g_allMoves = [];
    RedrawBoard();
    UpdateEvalBar(0);
    RefreshEvalBar();
    UpdateControlVisibility();

    if (!g_playerWhite) {
        SearchAndRedraw();
    }
}

function EnsureAnalysisStopped() {
    if (g_analyzing && g_backgroundEngine != null) {
        g_backgroundEngine.terminate();
        g_backgroundEngine = null;
    }
}

function UIAnalyzeToggle() {
    if (InitializeBackgroundEngine()) {
        if (!g_analyzing) {
            g_backgroundEngine.postMessage("analyze");
        } else {
            EnsureAnalysisStopped();
        }
        g_analyzing = !g_analyzing;
        var btn = document.getElementById("AnalysisToggleLink");
        if (btn) btn.classList.toggle('active', g_analyzing);
    } else {
        alert("Peramban Anda harus mendukung web workers untuk analisis - (chrome4, ff4, safari)");
    }
}

function UIChangeFEN() {
    if (!g_changingFen) {
        var fenTextBox = document.getElementById("FenTextBox");
        var result = InitializeFromFen(fenTextBox.value);
        if (result.length != 0) {
            UpdatePVDisplay(result);
            return;
        } else {
            UpdatePVDisplay('');
        }
        g_allMoves = [];
        g_selectedSquare = null;
        g_legalTargets = [];

        EnsureAnalysisStopped();
        InitializeBackgroundEngine();

        g_playerWhite = !!g_toMove;
        g_backgroundEngine.postMessage("position " + GetFen());

        RedrawBoard();
        RefreshEvalBar();
    }
}

function UIChangeStartPlayer() {
    g_playerWhite = !g_playerWhite;
    UINewGame();
}

function UpdatePgnTextBox(move) {
    var pgnTextBox = document.getElementById("PgnTextBox");
    if (g_toMove != 0) {
        pgnTextBox.value += moveNumber + ". ";
        moveNumber++;
    }
    pgnTextBox.value += GetMoveSAN(move) + " ";
}

function UIChangeTimePerMove() {
    var timePerMove = document.getElementById("TimePerMove");
    g_timeout = parseInt(timePerMove.value, 10);
}

function FinishMove(bestMove, value, timeTaken, ply) {
    if (bestMove != null) {
        UIPlayMove(bestMove, BuildPVMessage(bestMove, value, timeTaken, ply));
    } else {
        alert("Magnus aja umur 13 tahun udah jadi GM, sedangkan kamu masih kalah sama Fahri, ya haha.");
    }
}

function UIPlayMove(move, pv) {
    // Capture piece/board info BEFORE the move is applied (needed for sound)
    var fromX = (move & 0xF) - 4;
    var fromY = ((move >> 4) & 0xF) - 2;
    var toX   = ((move >> 8) & 0xF) - 4;
    var toY   = ((move >> 12) & 0xF) - 2;
    var movingPiece   = g_board[MakeSquare(fromY, fromX)];
    var capturedPiece = g_board[MakeSquare(toY, toX)];
    var isEP = !!(move & moveflagEPC);

    UpdatePgnTextBox(move);
    g_allMoves[g_allMoves.length] = move;
    MakeMove(move);
    UpdatePVDisplay(pv);
    UpdateFromMove(move);

    PlayMoveSoundForMove(move, movingPiece, capturedPiece, isEP);
    RefreshEvalBar();
    CheckGameOver();
}

function UIUndoMove() {
    if (g_allMoves.length == 0) return;

    if (g_backgroundEngine != null) {
        g_backgroundEngine.terminate();
        g_backgroundEngine = null;
    }

    UnmakeMove(g_allMoves[g_allMoves.length - 1]);
    g_allMoves.pop();

    if (g_playerWhite != !!g_toMove && g_allMoves.length != 0) {
        UnmakeMove(g_allMoves[g_allMoves.length - 1]);
        g_allMoves.pop();
    }

    g_selectedSquare = null;
    g_legalTargets = [];
    g_gameOver = false;
    UICloseGameOverDialog();
    RedrawBoard();
    RefreshEvalBar();
    UpdateControlVisibility();
}
var g_evalEngine = null;
var g_evalEngineValid = true;

function RefreshEvalBar() {
    // Always fully tear down and recreate — a worker mid-"analyze" does not
    // reliably accept a fresh "position" (the same limitation the main
    // engine has, which is why SearchAndRedraw() restarts g_backgroundEngine
    // every time instead of repositioning a live worker).
    if (g_evalEngine != null) {
        try { g_evalEngine.terminate(); } catch (e) { /* ignore */ }
        g_evalEngine = null;
    }
    g_evalEngineValid = true;

    try {
        g_evalEngine = new Worker(g_engineFiles[g_engineLevel]);
        g_evalEngine.onmessage = function (e) {
            var text = e.data;
            if (typeof text !== 'string') return;
            var match = text.match(/Score:(-?\d+)/);
            if (match) {
                var score = parseInt(match[1], 10);
                if (g_toMove === 0) score = -score;
                UpdateEvalBar(score);
            }
        };
        g_evalEngine.onerror = function () { g_evalEngineValid = false; };
        g_evalEngine.postMessage("position " + GetFen());
        g_evalEngine.postMessage("analyze");
    } catch (err) {
        g_evalEngineValid = false;
        g_evalEngine = null;
    }
}

function ResetEvalEngine() {
    if (g_evalEngine != null) {
        try { g_evalEngine.terminate(); } catch (e) { /* ignore */ }
        g_evalEngine = null;
    }
    g_evalEngineValid = true;
}

// ── GAME OVER DETECTION / DIALOG / BUTTON VISIBILITY ───────────────────────────
// Runs after every applied move. Reliable because it checks the actual legal
// move list ourselves, rather than depending on undocumented engine message
// formats.
function CheckGameOver() {
    if (g_gameOver) return true;

    var moves = GenerateValidMoves();
    if (moves.length > 0) return false;

    // No legal moves for the side to move: game has ended.
    var sideToMoveIsPlayer = IsPlayersTurn();

    // Try to distinguish checkmate (decisive) from stalemate (draw) if the
    // engine exposes a check-detection function under a common name. If not
    // available, default to decisive — matches this app's original
    // (pre-existing) assumption that "no legal moves" means checkmate.
    var inCheck = true;
    try {
        if (typeof IsInCheck === 'function') inCheck = !!IsInCheck(g_toMove);
        else if (typeof InCheck === 'function') inCheck = !!InCheck(g_toMove);
        else if (typeof IsKingInCheck === 'function') inCheck = !!IsKingInCheck(g_toMove);
    } catch (e) { /* keep default */ }

    g_gameOver = true;
    EnsureAnalysisStopped();
    UpdateControlVisibility();

    if (!inCheck) {
        ShowGameOverDialog('draw');
    } else if (sideToMoveIsPlayer) {
        ShowGameOverDialog('loss');
    } else {
        ShowGameOverDialog('win');
    }
    return true;
}

function ShowGameOverDialog(result) {
    var modal = document.getElementById('gameOverModal');
    var msgEl = document.getElementById('gameOverMessage');
    if (!modal || !msgEl) return;

    var msg;
    if (result === 'win') msg = 'Kamu mengalahkan Fahri!';
    else if (result === 'draw') msg = 'Kamu berhasil bertahan melawan Fahri!';
    else msg = 'haha masih bisa kalah sama Fahri!';

    msgEl.textContent = msg;
    modal.style.display = 'flex';
}

function UICloseGameOverDialog() {
    var modal = document.getElementById('gameOverModal');
    if (modal) modal.style.display = 'none';
}

// "Permainan Baru" button inside the game-over dialog
function UIGameOverNewGame() {
    UICloseGameOverDialog();
    UINewGame();
}

// "Tunggu" button inside the game-over dialog — stay on the final position
function UIGameOverWait() {
    UICloseGameOverDialog();
    UpdateControlVisibility();
}

// Both the "Permainan Baru" and "Menyerah" icon buttons call this. Once the
// game has already ended there's nothing to confirm, so it resets straight
// away; during an active game it still asks for confirmation first.
function UIResetOrSurrender() {
    if (g_gameOver) {
        UINewGame();
    } else {
        UINewGameConfirm();
    }
}

// Shows/hides the New Game vs Surrender icon buttons depending on mode and
// whether the game has ended.
function UpdateControlVisibility() {
    var btnNew    = document.getElementById('btnNewGame');
    var btnResign = document.getElementById('btnResign');
    if (!btnNew || !btnResign) return;

    if (g_gameOver) {
        btnNew.style.display    = 'flex';
        btnResign.style.display = 'none';
    } else {
        btnResign.style.display = 'flex';
        btnNew.style.display    = (g_mode === 'challenge') ? 'none' : 'flex';
    }
}

// ── EVALUATION BAR ───────────────────────────────────────────────────────────
function UpdateEvalBar(scoreInternal) {
    var barBlack = document.getElementById('evalBarBlack');
    var barWhite = document.getElementById('evalBarWhite');
    var label    = document.getElementById('evalBarLabel');
    if (!barBlack || !barWhite) return;

    var whitePct, displayPawn;

    // Mate score threshold (internal units: minEval+2000 / maxEval-2000 ≈ ±1,998,000)
    var MATE_THRESHOLD = 1900000;

    if (Math.abs(scoreInternal) >= MATE_THRESHOLD) {
        // Forced mate detected — push bar to near-total (Chess.com style: leave a 3% sliver)
        whitePct = scoreInternal > 0 ? 99 : 1;
        displayPawn = scoreInternal > 0 ? 99.9 : -99.9;
    } else {
        var cp = scoreInternal / 8; // internal units → centipawns (1 pawn ≈ 100 cp)

        // Sigmoid mapping: tanh gives natural S-curve identical to Chess.com feel.
        // 650 cp constant: ±300 cp ≈ 63/37, ±600 cp ≈ 76/24, ±1200 cp ≈ 88/12
        whitePct = 50 * (1 + Math.tanh(cp / 650));

        // Hard clamp: always show a tiny sliver on each side (Chess.com leaves ~3%)
        whitePct    = Math.max(3, Math.min(97, whitePct));
        displayPawn = Math.max(-99.9, Math.min(99.9, cp / 100));
    }

    var blackPct = 100 - whitePct;
    barBlack.style.height = blackPct.toFixed(1) + '%';
    barWhite.style.height = whitePct.toFixed(1) + '%';

    var sign = displayPawn >= 0 ? '+' : '';
    label.textContent = sign + displayPawn.toFixed(1);
}

function UpdatePVDisplay(pv) {
    if (pv != null) {
        var outputDiv = document.getElementById("output");
        if (outputDiv.firstChild != null) {
            outputDiv.removeChild(outputDiv.firstChild);
        }
        outputDiv.appendChild(document.createTextNode(pv));
    }
}

function SearchAndRedraw() {
    if (g_analyzing) {
        EnsureAnalysisStopped();
        InitializeBackgroundEngine();
        g_backgroundEngine.postMessage("position " + GetFen());
        g_backgroundEngine.postMessage("analyze");
        return;
    }

    if (InitializeBackgroundEngine()) {
        g_backgroundEngine.postMessage("search " + g_timeout);
    } else {
        Search(FinishMove, 99, null);
    }
}

var g_backgroundEngineValid = true;
var g_backgroundEngine;

function InitializeBackgroundEngine() {
    if (!g_backgroundEngineValid) return false;

    if (g_backgroundEngine == null) {
        g_backgroundEngineValid = true;
        try {
            g_backgroundEngine = new Worker(g_engineFiles[g_engineLevel]);
            g_backgroundEngine.onmessage = function (e) {
                if (e.data.match("^pv") == "pv") {
                    UpdatePVDisplay(e.data.substr(3, e.data.length - 3));
                } else if (e.data.match("^message") == "message") {
                    EnsureAnalysisStopped();
                    UpdatePVDisplay(e.data.substr(8, e.data.length - 8));
                } else {
                    UIPlayMove(GetMoveFromString(e.data), null);
                }
            }
            g_backgroundEngine.error = function (e) {
                alert("Kesalahan dari background worker:" + e.message);
            }
            g_backgroundEngine.postMessage("position " + GetFen());
        } catch (error) {
            g_backgroundEngineValid = false;
        }
    }

    return g_backgroundEngineValid;
}

// ═══════════════════════════════════════════════════════════════════════════
// SOUND ENGINE (Web Audio API) — ported from puzzles.html, piece-agnostic
// engine logic, only wired up via PlayMoveSoundForMove() above.
// ═══════════════════════════════════════════════════════════════════════════
        // =====================================================
        // PIECE SVG DEFINITIONS (Wikimedia Commons Style)
        // =====================================================
        const PIECE_SVG = {
            'wK': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 45 45"><g fill="none" fill-rule="evenodd" stroke="#000" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"><path stroke-linejoin="miter" d="M22.5 11.63V6M20 8h5"/><path fill="#fff" stroke-linecap="butt" stroke-linejoin="miter" d="M22.5 25s4.5-7.5 3-10.5c0 0-1-2.5-3-2.5s-3 2.5-3 2.5c-1.5 3 3 10.5 3 10.5"/><path fill="#fff" d="M12.5 37c5.5 3.5 14.5 3.5 20 0v-7s9-4.5 6-10.5c-4-6.5-13.5-3.5-16 4V27v-3.5c-2.5-7.5-12-10.5-16-4-3 6 6 10.5 6 10.5v7"/><path d="M12.5 30c5.5-3 14.5-3 20 0M12.5 33.5c5.5-3 14.5-3 20 0M12.5 37c5.5-3 14.5-3 20 0"/></g></svg>`,
            'wQ': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 45 45"><g fill="#fff" fill-rule="evenodd" stroke="#000" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"><path d="M8 12a2 2 0 1 1-4 0 2 2 0 1 1 4 0zM24.5 7.5a2 2 0 1 1-4 0 2 2 0 1 1 4 0zM41 12a2 2 0 1 1-4 0 2 2 0 1 1 4 0zM16 9a2 2 0 1 1-4 0 2 2 0 1 1 4 0zM33 9a2 2 0 1 1-4 0 2 2 0 1 1 4 0z"/><path stroke-linecap="butt" d="M9 26c8.5-1.5 21-1.5 27 0l2-12-7 11V11l-5.5 13.5-3-15-3 15-5.5-14V25L6 14l3 12z"/><path stroke-linecap="butt" d="M9 26c0 2 1.5 2 2.5 4 1 1.5 1 1 .5 3.5-1.5 1-1.5 2.5-1.5 2.5-1.5 1.5.5 2.5.5 2.5 6.5 1 16.5 1 23 0 0 0 1.5-1 0-2.5 0 0 .5-1.5-1-2.5-.5-2.5-.5-2 .5-3.5 1-2 2.5-2 2.5-4-8.5-1.5-18.5-1.5-27 0z"/><path fill="none" d="M11.5 30c3.5-1 18.5-1 22 0M12 33.5c6-1 15-1 21 0"/></g></svg>`,
            'wR': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 45 45"><g fill="#fff" fill-rule="evenodd" stroke="#000" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"><path stroke-linecap="butt" d="M9 39h27v-3H9v3zM12 36v-4h21v4H12zM11 14V9h4v2h5V9h5v2h5V9h4v5"/><path d="M34 14l-3 3H14l-3-3"/><path stroke-linecap="butt" stroke-linejoin="miter" d="M31 17v12.5H14V17"/><path d="M31 29.5l1.5 2.5h-20l1.5-2.5"/><path fill="none" stroke-linejoin="miter" d="M11 14h23"/></g></svg>`,
            'wB': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 45 45"><g fill="none" fill-rule="evenodd" stroke="#000" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"><g fill="#fff" stroke-linecap="butt"><path d="M9 36c3.39-.97 10.11.43 13.5-2 3.39 2.43 10.11 1.03 13.5 2 0 0 1.65.54 3 2-.68.97-1.65.99-3 .5-3.39-.97-10.11.46-13.5-1-3.39 1.46-10.11.03-13.5 1-1.35.49-2.32.47-3-.5 1.35-1.46 3-2 3-2z"/><path d="M15 32c2.5 2.5 12.5 2.5 15 0 .5-1.5 0-2 0-2 0-2.5-2.5-4-2.5-4 5.5-1.5 6-11.5-5-15.5-11 4-10.5 14-5 15.5 0 0-2.5 1.5-2.5 4 0 0-.5.5 0 2z"/><path d="M25 8a2.5 2.5 0 1 1-5 0 2.5 2.5 0 1 1 5 0z"/></g><path stroke-linejoin="miter" d="M17.5 26h10M15 30h15m-7.5-14.5v5M20 18h5"/></g></svg>`,
            'wN': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 45 45"><g fill="none" fill-rule="evenodd" stroke="#000" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"><path fill="#fff" d="M22 10c10.5 1 16.5 8 16 29H15c0-9 10-6.5 8-21"/><path fill="#fff" d="M24 18c.38 2.91-5.55 7.37-8 9-3 2-2.82 4.34-5 4-1.042-.94 1.41-3.04 0-3-1 0 .19 1.23-1 2-1 0-4.003 1-4-4 0-2 6-12 6-12s1.89-1.9 2-3.5c-.73-.994-.5-2-.5-3 1-1 3 2.5 3 2.5h2s.78-1.992 2.5-3c1 0 1 3 1 3"/><path fill="#000" d="M9.5 25.5a.5.5 0 1 1-1 0 .5.5 0 1 1 1 0zM14.933 15.75a.5 1.5 30 1 1-.866-.5.5 1.5 30 1 1 .866.5z"/></g></svg>`,
            'wP': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 45 45"><path d="M22.5 9c-2.21 0-4 1.79-4 4 0 .89.29 1.71.78 2.38C17.33 16.5 16 18.59 16 21c0 2.03.94 3.84 2.41 5.03-3 1.06-7.41 5.55-7.41 13.47h23c0-7.92-4.41-12.41-7.41-13.47 1.47-1.19 2.41-3 2.41-5.03 0-2.41-1.33-4.5-3.28-5.62.49-.67.78-1.49.78-2.38 0-2.21-1.79-4-4-4z" fill="#fff" stroke="#000" stroke-width="1.5" stroke-linecap="round"/></svg>`,
            'bK': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 45 45"><g fill="none" fill-rule="evenodd" stroke="#000" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"><path stroke-linejoin="miter" d="M22.5 11.63V6M20 8h5"/><path fill="#000" stroke-linecap="butt" stroke-linejoin="miter" d="M22.5 25s4.5-7.5 3-10.5c0 0-1-2.5-3-2.5s-3 2.5-3 2.5c-1.5 3 3 10.5 3 10.5"/><path fill="#000" d="M12.5 37c5.5 3.5 14.5 3.5 20 0v-7s9-4.5 6-10.5c-4-6.5-13.5-3.5-16 4V27v-3.5c-2.5-7.5-12-10.5-16-4-3 6 6 10.5 6 10.5v7"/><path stroke="#fff" stroke-width="1.5" d="M12.5 30c5.5-3 14.5-3 20 0M12.5 33.5c5.5-3 14.5-3 20 0M12.5 37c5.5-3 14.5-3 20 0"/><path fill="none" stroke="#fff" stroke-width="1" d="M20.5 25s3-5 2.5-8.5M24.5 25s-3-5-2.5-8.5"/></g></svg>`,
            'bQ': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 45 45"><g fill-rule="evenodd" stroke="#000" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"><g fill="#000" stroke="none"><circle cx="6" cy="12" r="2.75"/><circle cx="14" cy="9" r="2.75"/><circle cx="22.5" cy="8" r="2.75"/><circle cx="31" cy="9" r="2.75"/><circle cx="39" cy="12" r="2.75"/></g><path fill="#000" stroke-linecap="butt" d="M9 26c8.5-1.5 21-1.5 27 0l2.5-12.5L31 25l-.3-14.1-5.2 13.6-3-14.5-3 14.5-5.2-13.6L14 25 6.5 13.5 9 26z"/><path fill="#000" stroke-linecap="butt" d="M9 26c0 2 1.5 2 2.5 4 1 1.5 1 1 .5 3.5-1.5 1-1.5 2.5-1.5 2.5-1.5 1.5.5 2.5.5 2.5 6.5 1 16.5 1 23 0 0 0 1.5-1 0-2.5 0 0 .5-1.5-1-2.5-.5-2.5-.5-2 .5-3.5 1-2 2.5-2 2.5-4-8.5-1.5-18.5-1.5-27 0z"/><path fill="none" stroke="#fff" d="M11.5 30c3.5-1 18.5-1 22 0M12 33.5c6-1 15-1 21 0"/></g></svg>`,
            'bR': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 45 45"><g fill-rule="evenodd" stroke="#000" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"><path fill="#000" stroke-linecap="butt" d="M9 39h27v-3H9v3zM12.5 32l1.5-2.5h17l1.5 2.5h-20zM12 36v-4h21v4H12z"/><path fill="#000" stroke-linecap="butt" stroke-linejoin="miter" d="M14 29.5v-13h17v13H14z"/><path fill="#000" stroke-linecap="butt" d="M14 16.5L11 14h23l-3 2.5H14zM11 14V9h4v2h5V9h5v2h5V9h4v5H11z"/><path fill="none" stroke="#fff" stroke-linejoin="miter" stroke-width="1" d="M12 35.5h21M13 31.5h19M14 29.5h17M14 16.5h17M11 14h23"/></g></svg>`,
            'bB': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 45 45"><g fill="none" fill-rule="evenodd" stroke="#000" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"><g fill="#000" stroke-linecap="butt"><path d="M9 36c3.39-.97 10.11.43 13.5-2 3.39 2.43 10.11 1.03 13.5 2 0 0 1.65.54 3 2-.68.97-1.65.99-3 .5-3.39-.97-10.11.46-13.5-1-3.39 1.46-10.11.03-13.5 1-1.35.49-2.32.47-3-.5 1.35-1.46 3-2 3-2z"/><path d="M15 32c2.5 2.5 12.5 2.5 15 0 .5-1.5 0-2 0-2 0-2.5-2.5-4-2.5-4 5.5-1.5 6-11.5-5-15.5-11 4-10.5 14-5 15.5 0 0-2.5 1.5-2.5 4 0 0-.5.5 0 2z"/><path d="M25 8a2.5 2.5 0 1 1-5 0 2.5 2.5 0 1 1 5 0z"/></g><path stroke="#fff" stroke-linejoin="miter" d="M17.5 26h10M15 30h15m-7.5-14.5v5M20 18h5"/></g></svg>`,
            'bN': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 45 45"><g fill="none" fill-rule="evenodd" stroke="#000" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"><path fill="#000" stroke="#333" d="M22 10c10.5 1 16.5 8 16 29H15c0-9 10-6.5 8-21"/><path fill="#000" stroke="#333" d="M24 18c.38 2.91-5.55 7.37-8 9-3 2-2.82 4.34-5 4-1.042-.94 1.41-3.04 0-3-1 0 .19 1.23-1 2-1 0-4.003 1-4-4 0-2 6-12 6-12s1.89-1.9 2-3.5c-.73-.994-.5-2-.5-3 1-1 3 2.5 3 2.5h2s.78-1.992 2.5-3c1 0 1 3 1 3"/><circle cx="9" cy="25.5" r="1.5" fill="#fff"/><ellipse cx="14.5" cy="15.5" rx="1.5" ry="3" fill="#fff" transform="rotate(30 14.5 15.5)"/><path fill="none" stroke="#555" stroke-width="1" d="M25 10.5c4 1 7 3 9 7M27 14c2 1 4 3 5 6"/></g></svg>`,
            'bP': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 45 45"><path d="M22.5 9c-2.21 0-4 1.79-4 4 0 .89.29 1.71.78 2.38C17.33 16.5 16 18.59 16 21c0 2.03.94 3.84 2.41 5.03-3 1.06-7.41 5.55-7.41 13.47h23c0-7.92-4.41-12.41-7.41-13.47 1.47-1.19 2.41-3 2.41-5.03 0-2.41-1.33-4.5-3.28-5.62.49-.67.78-1.49.78-2.38 0-2.21-1.79-4-4-4z" fill="#000" stroke="#333" stroke-width="1.5" stroke-linecap="round"/></svg>`
        };

    // =====================================================
        // SOUND ENGINE (Web Audio API)
        // =====================================================
        let audioCtx = null;
        let woodConvolver = null;
        
        const SOUND_PARAMS = {
            masterVol: 0.7,
            woodQ: 10,
            decayMs: 94,
            convolverWet: 0.6,
            slideVol: 0.25,
            durationScale: 1.2, // 20% longer move sounds
        };
        
        const PIECE_WEIGHT = { 'p': 1, 'n': 2, 'b': 2, 'r': 3, 'q': 5, 'k': 4 };
        
        // =====================================================
        // PIECE MODAL PROFILES
        // =====================================================
        // Each piece has its own set of resonant modes.
        // King is the largest piece (deepest, most modes, longest decay).
        
        const PIECE_PROFILES = {
            p: {
                volume: 0.35, liftPitch: 1.35,
                modes: [
                    { freq: 660, amp: 0.7, q: 5, decay: 0.7 },
                    { freq: 820, amp: 1.0, q: 6, decay: 0.8 },
                    { freq: 950, amp: 0.5, q: 4, decay: 0.6 },
                ],
                toneFreq: 780, thumpFreq: 160, thumpAmp: 0.15, decayMult: 0.95,
            },
            n: {
                volume: 0.42, liftPitch: 1.40,
                modes: [
                    { freq: 520, amp: 0.5, q: 5, decay: 0.9 },
                    { freq: 710, amp: 1.0, q: 7, decay: 1.0 },
                    { freq: 880, amp: 0.6, q: 5, decay: 0.7 },
                    { freq: 1150, amp: 0.3, q: 4, decay: 0.5 },
                ],
                toneFreq: 640, thumpFreq: 140, thumpAmp: 0.22, decayMult: 1.15,
            },
            b: {
                volume: 0.42, liftPitch: 1.30,
                modes: [
                    { freq: 440, amp: 0.4, q: 5, decay: 1.1 },
                    { freq: 620, amp: 0.8, q: 6, decay: 1.0 },
                    { freq: 850, amp: 1.0, q: 7, decay: 0.85 },
                    { freq: 1200, amp: 0.4, q: 4, decay: 0.6 },
                ],
                toneFreq: 580, thumpFreq: 130, thumpAmp: 0.20, decayMult: 1.2,
            },
            r: {
                volume: 0.52, liftPitch: 1.25,
                modes: [
                    { freq: 320, amp: 0.6, q: 6, decay: 1.3 },
                    { freq: 480, amp: 1.0, q: 7, decay: 1.1 },
                    { freq: 680, amp: 0.7, q: 5, decay: 0.9 },
                    { freq: 920, amp: 0.35, q: 4, decay: 0.6 },
                    { freq: 1250, amp: 0.15, q: 3, decay: 0.4 },
                ],
                toneFreq: 420, thumpFreq: 100, thumpAmp: 0.30, decayMult: 1.4,
            },
            q: {
                volume: 0.55, liftPitch: 1.22,
                modes: [
                    { freq: 280, amp: 0.5, q: 6, decay: 1.4 },
                    { freq: 420, amp: 0.9, q: 7, decay: 1.2 },
                    { freq: 600, amp: 1.0, q: 8, decay: 1.0 },
                    { freq: 830, amp: 0.5, q: 5, decay: 0.7 },
                    { freq: 1100, amp: 0.2, q: 4, decay: 0.5 },
                ],
                toneFreq: 380, thumpFreq: 85, thumpAmp: 0.35, decayMult: 1.55,
            },
            k: {
                volume: 0.60, liftPitch: 1.20,
                modes: [
                    { freq: 240, amp: 0.45, q: 7, decay: 1.5 },
                    { freq: 370, amp: 0.8, q: 8, decay: 1.3 },
                    { freq: 520, amp: 1.0, q: 8, decay: 1.1 },
                    { freq: 720, amp: 0.6, q: 6, decay: 0.85 },
                    { freq: 980, amp: 0.3, q: 5, decay: 0.6 },
                    { freq: 1350, amp: 0.15, q: 3, decay: 0.4 },
                ],
                toneFreq: 340, thumpFreq: 75, thumpAmp: 0.40, decayMult: 1.7,
            },
        };
        
        // =====================================================
        // WOOD SAMPLES (CC0 - Freesound.org)
        // Hybrid engine: real samples as excitation + synthesis
        // =====================================================
        
        const WOOD_SAMPLE_DATA = {
            place: 'SUQzBAAAAAAAI1RTU0UAAAAPAAADTGF2ZjYwLjE2LjEwMAAAAAAAAAAAAAAA//twwAAAAAAAAAAAAAAAAAAAAAAASW5mbwAAAA8AAAAIAAALBQA4ODg4ODg4ODg4ODhVVVVVVVVVVVVVVVVxcXFxcXFxcXFxcXFxjo6Ojo6Ojo6Ojo6OqqqqqqqqqqqqqqqqqsfHx8fHx8fHx8fHx+Pj4+Pj4+Pj4+Pj4+P///////////////8AAAAATGF2YzYwLjMxAAAAAAAAAAAAAAAAJAWtAAAAAAAACwWa8nLrAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/7cMQAAA3ocTZ1h4ACmCvrazDwAQAAAPmuOQ5DOGcM4fhu5bM1KNRgMRFBiDuQ5MtbByBIBcDoVjyJSj++6PGBkeU373ve936sZImv/m7yICAIHCgIcQAgCBwSAhiAHwfB8P1AhggCDhODgIAg4TggCAIHPg/yhzy4PwcBB2CEuf/gg5AAACXZJqBMty3fiTBWaDC/nHGhm0YnBJZN0PWkCCTo5w0MVVkZECzCVoaQYlxLRwCtDgEJNFGQETCIYjDfMtbTzcdrZCeQz3IWz1Y79IvtoNOevf692Rvh2szMV///1Gp0LgIW1MjDZhQ2C9p/9f+EyOE7AqFt44fD6DFwwvdbpNfHx+q6aTiGOF87166hf2+s/6xrH/+9fd771n/FN09NQZfx4VYVABCc3dEVCHSkNioCXvL/+3LEBwMQFO9KfZiAAlCn50mzD0m6j4nM9Eti04DBxccJW8LRqXqjAVokxDxkBP5DSKiCJCEwXRCpfMDo+0x9kMIqSZRJgdBqmidLblWTqaj5uimp0Hut+u1aToVoJ0VO1kzJa1szW9fbrRoo6E3LAkoMvCp6HgrYvYEDwWNSQFYiKhsVJ/9wAAaCAY4ECIRMFHZjSgCBAArJod8UYYOCDBSY0cbL8GUjZjYAFQYDCRjhUVCowADQEkgwYOBMbmULX4Xq3xd9rMtWFcncYVYsCqZ4mEtZS6uM+aZDMPQDDUgm56D5k5Hlll7UX7xI9jruoTU4QgVUiIkNgO0bKKxJpnTZzJDKzelCX/Nr0pZP8uwvSsR6sJxcCn+t9QAWldyQw+QIEROA/xZQWUvmuw8sDQxAQEd3GBbm1P/7cMQPAxCxP0RsMRRCDyspDYMialhtgVVg57ka2DRthiW0Pyh/ZsRgnFSRQoCYrDmPC9BZuH4yECxrsiRK9FOj3ZQ0XJOHjyxUQT6knl6ptHOw84dvv/rx7Q3ytDvSlkkZOirEmrUEqI6ytz+szfB01NY1zzyUCp0C7F6gAkW9SoIysTHIgJ8l9lN1UlnrEdRiLV4MQZR/L7Iptctsod6HqLcCsOk32EIAEC5tHCxSBhm6cDCfBL6nroz7RTxzS1Bjz7tN1ExAMe+t8TKjZNj5mxfuKhhZZq+CHGZudcUTX+k1c/KtF8Y5RgsLK64uaxYlCoiDYu17u5FpEQ0REvoVAAACjIUY0zFMMKRZpMHETCA0HGBjieYCOiw6YaWmUlZtEnPSGZgBI2rTL8PPZIFBJA4IACzQcFP/+3LEHAOS5NkybeTLwhuW5s2sGXgqYMnZWi6vNk8OxwvBfTCae5MPtqXkkChzyPInVDzgzEBOhGpq2Fhdmqz2hSBuIpESJEMEMwU4GYYFdlLZEFWmRx9X6x2xn2Vi5QiBoPAcuLFEgsOW46fu62oG61jY9gD3EKQyUwAwwURHgKThozQXFDCcw6duJdc1RLxHRElAgThkFfXo15CBnjR38U4Ko8Y8zCNxCRq1vwpU/6dTM4wsZsj1zunGwjMQoojNUFNqltucvKi1a3hzbJnBzkjZd+uvf5QaNmUsggy2eCU24ShEXMkRYGhWESiRlRdZ0nRc5OhOjWxFqgAAkhKHLwm6WmsXHFaHOADsEyUAVAmOKGXoNyOAdMl9Ikhp2gGEHpUHYSA4guocNmMSQ0w8oGJXwKguFwDdUf/7cMQfg5KU8SxNJHqCaqRlhayZevlrozvEkenEtdDFyH6LhOs9UAs8f1Z9RbDbsgf6YqE64gf7ggY3OmyURD/mR+NEy2q3NUsfpgwwkb24xy8/MrqV6bSBEBBpiRRRt4jQZ4cIVKIBvy1Y5GepaZX8fQeFBoGsmJGCgoKgjTugaSNWKMhMS0ORA5GxdENJFd03Q5kM6B3JehWESLVuVvZ8jMk+0ovK9Kp4KaUwdpKFCp3dTXdV05dK3GjroPrLpbOUw9E2KqJlpZ/L4cXCQTNB7IEFKI9OgYyEGsk9793flO3z+NQLhulv35kY5/m7/awfshnTABg0DJAQCf0AcRjQPb9jO9UAmvmNnA3IYoSF4BgDCXxiBZsx6GZlQqX59kgeptweKcaxmKiXCKSYCGpmmhx7gKAp1u3/+3LEGYMT1TksLWTL0l2npcmWItCtFQFON/28U0gRWNqDjNFag8jO2lPYwBD1+X5nYCkEC0/YWkhDJdkmZF0370as4uGSxln1Cj9Xp+GXcvOn+d/1qx8f/M1/u1Dd6VyystqNTNMKAupgpAkoAGKErLsoNHuUBwKgQIJa1+jpq1AQApIGZH5glG+CagqS4ckMTGo6AvEOxnCmeKTILiPuQAOiMESfRlLujgA0Mz6VtkQpa1SMwXU/sXfiXrhW6BxMSUEfQJHo/iAIUSAxp10S1U4z+0vHBC45TJV9CGq1r69zAgeNYGq9rWt8JRLC8L+tRMRX6J9W0EIr4pIcg+gq7j8+B7yo0dpj1O6ypQDpRrFphQQQlNYEA0S24lsGVgpSjSAoxHeFfqwrSUHC+cSDIrjChxoL0z8qX//7cMQRAw8xMzRMDNsB/CakCYYhsFMuLejH/tpVqR01i1SSS/TbjNWVT262E1f5Gv/9gqFQ52HTpGnDQeZX7AZ7KhqIqCi/M4ZIO6yfUfh5/P1nmJiLhGFnaRTXly4MRUl3rlZ4gky+AoqtWRAkBaQCoA0khgCQ10PtkWkESPrLRCQmGYjpmhyB0SUMxEkSSbEy4JTDcQ5IySJJZKyQSjIlFpKJJjRaPQHi1q2n8yHsM1r7M1ytf5R18rUiqC1/sSsXPqvG1qv6r/FrqqrX/w1rrGDoLYemYWNKOZmtQ6NDoa/OrcoeSEqfnSqVAEEgKYqhUEaHIIZVuRBHQDoEO6eiw7LHfJA1hYFg5kw3NT4xHIeSCVD+L7MpkNDOF6JUenRVLxeTrH6bkMEAcjs/9UVFVP1VP+7OUwX/+3LEJoPOaMrUTDBNgAAANIAAAAQECUEzLukWFWLFRTSCwqGa+LCwqRxRv1iopgIWEZkBBIXM///6hVVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVQ==',
            lift: 'SUQzBAAAAAAAI1RTU0UAAAAPAAADTGF2ZjYwLjE2LjEwMAAAAAAAAAAAAAAA//twwAAAAAAAAAAAAAAAAAAAAAAASW5mbwAAAA8AAAAFAAAHWABVVVVVVVVVVVVVVVVVVVVVVVVVgICAgICAgICAgICAgICAgICAgICqqqqqqqqqqqqqqqqqqqqqqqqqqtXV1dXV1dXV1dXV1dXV1dXV1dXV//////////////////////////8AAAAATGF2YzYwLjMxAAAAAAAAAAAAAAAAJAKDAAAAAAAAB1hQJv0JAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/7cMQAAA1sgyh1hgACiCUv9zDyQgAEgjHLh+X5509O8BfwzlAx1L48wxnEOUkYEct44nCcAMD64EwPn+U1eZn5gYHjmtr/WCWZr169eZr/Xr195osc1YsOA+fwxxAciQ56wfLg4CAIAgCAPg+D/5QEAx+D4Pn/z5QEDijnlwfD8UiiLSjUssd1+g9/wFCrCz8TRpf1kqnIXKWBFzWtP4gHb+VJVUt0MMnZoBJEydRjgI6FiZGkaR1LlZOMJGF+PME8epojmi4lZVQT88yWaMElp+JFQ2g1to0w6C4OC4LYjGGKdp/IVXWNbwcBxn4jJ2CI1qZVLmFv///9Tz1f5Z5X1PCj71C16/1///ODN2SHH3ijI8bVDSCytWny/GVv//lh6gAAU5BEkDCjLNFIjMdWqKimB+d4IRP/+3LECwOQbIlEfZyACkOip0WjD0IVjGboIiTFECo4KFDnkEIDVHgmhiprVxpEvmjK/y8kVV8tvArrwM2aRSqC49N8vTMap4pdjkZhUXaY48suxC7h9fV/D7lexu1VO56q8u9pPs19/8JmxG/66Mzucz2/d1ZsrdrXpxZJ19u//+QzZyDIdNEa4qYjOcAQBkZkUAUwGfoG8CmHCmcPtPMgBDhIUWp0GAAFoTHITNDgYfAAMMApzlwEswaARgHQKRCii52hOwp3D087sgjESbrGW4VVAGWpbNq1lkjsuTIOARYgSQCAy7KwKDFavGY+m7ecckHjGQI/hdKsVh8LppKROX5kf3vVgMwGAD6CwokQYdemmqoABJvUdiAii03QHVhEAIz4kIQXnITwCBKhQwvYYoVChiNPA6BMUP/7cMQTAxE5WUBssHUCdahmiaeOmeFFhXDjaq4oKgusEy94laluYLYfQJiodJRgaj+TkRGJxJSmK51Re9asPPWnXKLWPpD1n3qfrkCgUhVkYur35vZWRkdCMhPtnfLzy88krwGmmCm9NZFJ4ZkhOZnbYYSUGDLHTywAU4VYCyxrIPZmSvm0Cp2GAWCFIYIga4QW9MsRMQNOfFM4bB1AxIkgRDyceNiQg3xUHA0jSIsBU6c4MCIS1gAvCXINJHdKtwlOri3kWXInZkGkP0+y7sKyMlcPkykFtZnizMFrXoOLBqHE6OZUwlCQMoVwzA9LcyIrEfrjOZDFXE4Jfn/z/LxyIAINCKzKoh5XrixKVrjQEY+hmk391QAC4dGlHYahsZboKRKxUvyEVIQBGq1rCg4IDJGQNG2JJzP/+3LEEQMQgVU+bKS0wo4qpgmsobD2jmjyKEJWr2mL61k0WCw5HAswCBtutw8uhmsVhoRJBGOI91CmuRqXF0o1lmkcZd6FVSsPchCCxnd3VqtQhmZkKGuRKvI9//+r1GqcfQyNZzOcwfDUczjg9Lcs48LiiX6digAUkt+fBUWExiWBp8BlwI6QARkGhTJGTNhjHojEnj2FV/i3yTJihhsxGmaDYMCP0QMGQ0bKnUhLLMO8u1NR/IHUPgmTQ2xaCpRBjDmCNxVuSPhhsagscXOw11FmiEHILiBUMCEC1kLhmextUQer9aDYmw+gSodD9/DQlQyiFY0UxrxLfd9f/9f/Cw48+HaPmpfY6RBD81RkXer08QMDJGVtT9S1AJhQpGdgpj9H+gYLBEcY4wNMA0Rk1BFwENJHj1IM4v/7cMQPgxLJPSpMmLrJ8A8hSZwk+EZGRie1TFbhhhK6QFFvlb1IReXs5ZQ27hY5zUalslXazm9edKF3G5MmljOl8t7NsRorLaaRUJCaxKEqNAOHZ5mZnH358atmYqqruROJajy0ZFKs1FmJb2pzflb6MmZWUOi2rbGiQeAYPBLqzf/IbihFG//JBXF6AAgYANgbkyVBGeDmDbGMiEyADrIaCabCToDMDUIENnCZc9SumQvapUn0FAqIJjOS/KeyrkxXgh+BY1WKjANCEShYnBFGAFACRoKiUiJsRNTQ4DQmCQOkQl6wSbJBJ4FSoqIiTP/2hwGhKIiR0KuAS02qYRdbnfJBQeoKgJVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVU=',
            capture: 'SUQzBAAAAAAAI1RTU0UAAAAPAAADTGF2ZjYwLjE2LjEwMAAAAAAAAAAAAAAA//twwAAAAAAAAAAAAAAAAAAAAAAASW5mbwAAAA8AAAAJAAAMPgAzMzMzMzMzMzMzM0xMTExMTExMTExMZmZmZmZmZmZmZmaAgICAgICAgICAgJmZmZmZmZmZmZmZs7Ozs7Ozs7Ozs7PMzMzMzMzMzMzMzObm5ubm5ubm5ubm//////////////8AAAAATGF2YzYwLjMxAAAAAAAAAAAAAAAAJAaRAAAAAAAADD6KfepeAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/7cMQAAA1IcygVhgACoi1sfzDwATOMvm7SCQtIgAYJBKJ5iAXwfVL9MOD2ULEkIAgHFG4cCQWCuAAAQmVOzM/+i9evf/KddYsc7b3+h2vff4gBAoCCwfPg/wTD8Tn4gOS4PxANBAMKDGsP+CHBAuCDv+sPiMH///5SCDi58ufAAAAoyIQRFMykmjRLkskodkyxQRD1kOL/hF0DGKloY83xr2eVoUEi3WYCOBoAWhYpJyFltFzFqdkiLyyu3ZOzrjyJVMJnbE+jrEd47YENcWBSo2NfFLKiR6ozguc6enapmTP+PJRnj9WKyJHy9y+hMW/v5/Z8UxS7zV7WzCtjD7eN4/t/Wr/dKaVkV/M/yrYuva28fP1b///+8TXziI541//9f7rWDrg1AQC0URG0QlHomIxAYK3MxFT/+3LECIMPgMNGXZeAAlUgZ0W3pXIwl0lnKifVr0va7CaccQvmBTj+ZEC9Q5kwuIKajuEzEpWFliyxnzFZs8mY9a1puE371E3L8yxcYtjGPv/Hm8tJX9/XV97gUvSWOIHj2lEni6DBwaoULMYkcn2ioIrtQbSAhbkTYiQ3QLKPaQBFSkzYMM7jDHTNG8RC5hAaZ2XAkPMZDxkFVcF+h59IFaT6cJ4WocQNkWFtLG3wz6TiyXJHLtX7TouKOUE6TduJzlyPES7aSqmrtITDGI4Nw2BaTMYFXFpkpEGqa6ITZF9yrkp0hUQoWVcab3YIWUpEz5SirJSfz7UNl4pB0k4ACnepMOzLXJfhsUEQwYWWQDbWKvcAlQAJAAAABcREAUcVlGdDEztD0xRgWICgcWOoT36gGPsild53E//7cMQSApJhXz1NJHVKWyGmgbSPGFpWzqCIMeBojAnzd+/TSsPQEyASbACSUWGRAuStErGoLT1jZDsZK9y6sIdJtpFPMXdNGRacnGUEeqTanIiRMNJeDGoY0d55FfeSCCkOpnFCyw/08vBoyr2WubCbDbleEXjUK9f8584nd28DPJeExRkcM0LjCgQPZiIRBpCLFxm5iZcRhcYQ8exorhM2YGy96I+0xvEBSCZlSnqZiMVz1DMFuNYfeG4+rJZeOPv20iKvOuCIlFI4iRNJtExxttYhOCdNzOyFRJJFNgPEiIhMEAlYLMa3DHk7YpKsiFklxoaigSiWOLFKDENoRF0FHJgeeNHLJnVK8FzSlKOuK3jcfRXv/+jT6akAAGJjpo6JlGpgrhkBYBFmGMmSDCqIKjQUxX44cGT/+3LEDwGSIP00TTDSwlWhplmmDnBBw5Q60GNlqvk1SnWLAg7EsIB7nQbDtcwAsVjRIsYg0kuDvR15ehypcJAOwwGdvIHqeJQOYxECLUIPkknMHJpIPKKR77szEbM7jobbXqGJZWv3j2doFAiywUIRxQ9zPTOPYB0wVWUPSLwvTFjgQWJf/R/pBBZIg1F43JAQOxYMRCw4uYwO65UBMPjdC/L+w64MuUdULZU6DvPHxZpUBs0c1QRASFWRgsQhi+2YFs2YHYmnEoqdH1j67bsTt8+B5hbME9DrHvHLjr3m0C9S1FSNQjovtWoCxAqDGQGVThKfmy1Ctso+pAlYE0DdjiHXOFlhdZYyfB4uweoYKoNi4sbg0LP/teSsk71qAACUAABICchFIw/Bhiz0bSwfYFJXq7QeikKQLv/7cMQOAA4Q4T2sMGnB8hlmVZYZqFdCuA8ejhEVT1aqViT/U97k6FbLxQssVbXCBSIEHfWsF0ycxp/f4qVVVT0yjz3kHnw6OlLLnwO00PMi2mVOkXJOpj3Eng2Z3vlGdab4rKh5Kw6hwTBAARbsQ5FtQsWDWUyQF+BSRKBN2XOnMrDXSKoJANUIJhwLlEMcTcjOwnx6VCyRDo7LJmSxwJq4sqQNNNHDnOmDKMvDsJJXNFsuZ24gJ2oXRntPoU6WOabGzvUcPannBgoSFhFe43WKnqmS5JKjLnLQkbv3dbtMVbX+z//pAQAAsqrGRSDggIoXAeIVOTUUvcF/7sZbHANLKYNxbVmFIjY1EwRKPKtigeKpLwLONN+BsMOPKVJKI14SIsOZws4ym4KH3Indh0HovpraGAwyDKT/+3LEKYOOAM00zKRwwZaYJkWWDXguNFxcKPhVA51txSlWE0WPY9qpCLEfQ3u/92j/6BJcmvc3pmLmKIqFg6rGivoxJ0MF0JaOiadmKA0bjBefQqEVtKSd54tele4gHJ+eNspqRfF1c3IzRvbMPCKPDKQd5W1IIYnIyRoOwuHBzSE+zvQlBJaOc44ZCh2y/u/pjq/9XoZdTQAUoiACrVGARiWx4wkedXizYZir7sGdODHjgJWAKi5KbcKUEUJ2KFiJEsca1HiLUC/dsVMduRVG9Itpb0KZU1Q0DJOpHmyCTYrMFgGKDjFhMmpJtL1wChgSCFKHK7srlWIp4bjHzQ8ADkAkaktSd2FQ66y9sFpfTebKG2tDwJSMDPMCpuy40rIkxlJzMyC8lqzTM+ck4VQjDVFtGZyo9Kd4Wf/7cMRRAAzgizeMJG1BtiDmpYSNcMMv+WpU4ZERtG4UK/fkJzJT7c5NeFk4IzA+PIihoJ2CrQmAnUNivqlV6hqF2Vn6bf/+tQBQCgAAuj2pL2hghZYMKWK1xIZsDrU7LbV6VRqmmpLO3BYTJic0yRKiMnrBUC3VQNQBCfuP5n2Hz4pfRMuVXyjcgpmZmAtxKTpERFoNKhqv1B7BUc9E2t1R1fLUg1r9v/KhR7H5Hj+S/ZSAACSSlWavgABbMmICjN1BQCjr/J1wlgMBDiIpc84ODJUWARoMFG2i1gsbhIwBLNjSOPRaNLDf42Kl+Ul/lXEscUXihn/+TvGkjvl8GlN/ybov9qx+XxQ3HdiT8UKLiX+DegvQZK7rbsopNUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVX/+3LEeIANRLsojJhxAamOoiWEmIlVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVUxBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVf/7cMRtg8AAAaQAAAAgAAA0gAAABFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVU=',
        };
        
        // Decoded AudioBuffers (populated in initAudio)
        let woodSampleBuffers = { place: null, lift: null, capture: null };
        let samplesLoaded = false;
        
        // =====================================================
        // SYNTHETIC WOOD IMPULSE RESPONSE (for ConvolverNode)
        // =====================================================
        
        function createWoodIR() {
            const sr = audioCtx.sampleRate;
            const duration = 0.08;
            const len = Math.ceil(sr * duration);
            const buf = audioCtx.createBuffer(1, len, sr);
            const data = buf.getChannelData(0);
            const modes = [
                { freq: 380, amp: 0.30, decay: 900 },
                { freq: 620, amp: 0.50, decay: 700 },
                { freq: 990, amp: 0.40, decay: 500 },
                { freq: 1330, amp: 0.25, decay: 380 },
                { freq: 1850, amp: 0.15, decay: 250 },
                { freq: 2470, amp: 0.10, decay: 180 },
                { freq: 3200, amp: 0.06, decay: 120 },
                { freq: 4500, amp: 0.03, decay: 80 },
            ];
            for (let i = 0; i < len; i++) {
                const t = i / sr;
                let sample = 0;
                for (const mode of modes) {
                    const env = mode.amp * Math.exp(-t * mode.decay);
                    const detune = 1.0 + (Math.sin(i * 0.01) * 0.002);
                    sample += env * Math.sin(2 * Math.PI * mode.freq * detune * t);
                }
                data[i] = sample;
            }
            const clickLen = Math.ceil(sr * 0.002);
            for (let i = 0; i < clickLen && i < len; i++) {
                const env = 1.0 - (i / clickLen);
                data[i] += env * env * 0.4 * (Math.random() * 2 - 1);
            }
            let peak = 0;
            for (let i = 0; i < len; i++) peak = Math.max(peak, Math.abs(data[i]));
            if (peak > 0) {
                const scale = 0.8 / peak;
                for (let i = 0; i < len; i++) data[i] *= scale;
            }
            return buf;
        }
        
        function initAudio() {
            if (!audioCtx) {
                audioCtx = new (window.AudioContext || window.webkitAudioContext)();
                woodConvolver = audioCtx.createConvolver();
                woodConvolver.buffer = createWoodIR();
                woodConvolver.normalize = false;
                woodConvolver.connect(audioCtx.destination);
                // Decode wood samples for hybrid engine
                loadWoodSamples();
            }
            if (audioCtx.state === 'suspended') {
                audioCtx.resume();
            }
        }
        
        // Decode base64 MP3 samples into AudioBuffers
        async function loadWoodSamples() {
            if (samplesLoaded || !audioCtx) return;
            try {
                for (const [name, b64] of Object.entries(WOOD_SAMPLE_DATA)) {
                    const binary = atob(b64);
                    const bytes = new Uint8Array(binary.length);
                    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
                    woodSampleBuffers[name] = await audioCtx.decodeAudioData(bytes.buffer.slice(0));
                }
                samplesLoaded = true;
            } catch (e) {
                // Fallback: pure synthesis continues to work
                console.warn('Wood sample decode failed, using pure synthesis:', e);
            }
        }
        
        // =====================================================
        // AUDIO ROUTING: Dry + Wet (Convolver)
        // =====================================================
        
        function createSoundOutput(time) {
            const sp = SOUND_PARAMS;
            const master = audioCtx.createGain();
            master.gain.setValueAtTime(sp.masterVol, time);
            const dry = audioCtx.createGain();
            dry.gain.setValueAtTime(1.0 - sp.convolverWet, time);
            dry.connect(audioCtx.destination);
            const wet = audioCtx.createGain();
            wet.gain.setValueAtTime(sp.convolverWet, time);
            wet.connect(woodConvolver);
            master.connect(dry);
            master.connect(wet);
            return master;
        }
        
        function createNoiseBuffer(duration) {
            const len = Math.ceil(audioCtx.sampleRate * duration);
            const buf = audioCtx.createBuffer(1, len, audioCtx.sampleRate);
            const data = buf.getChannelData(0);
            for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
            return buf;
        }
        
        function createBrownNoiseBuffer(duration) {
            const len = Math.ceil(audioCtx.sampleRate * duration);
            const buf = audioCtx.createBuffer(1, len, audioCtx.sampleRate);
            const data = buf.getChannelData(0);
            let last = 0;
            for (let i = 0; i < len; i++) {
                last = (last + (0.02 * (Math.random() * 2 - 1))) / 1.02;
                data[i] = last * 3.5;
            }
            return buf;
        }
        
        // =====================================================
        // CORE: WOOD CLICK (Modal Synthesis)
        // =====================================================
        
        function playWoodClick(volume, pitch, time, isPlace, piece) {
            if (!audioCtx) return;
            const sp = SOUND_PARAMS;
            const profile = piece ? PIECE_PROFILES[piece] : null;
            const decayMult = profile ? profile.decayMult : 1.0;
            const decayBase = (sp.decayMs / 1000) * decayMult;
            const vol = isPlace ? volume : volume * 0.45;
            const decay = isPlace ? decayBase : decayBase * 0.55;
            const tail = decay * 0.6;
            
            const output = createSoundOutput(time);
            
            // === HYBRID EXCITATION ===
            // Use real wood sample when available, noise burst as fallback
            const sampleType = isPlace ? 'place' : 'lift';
            const sampleBuf = woodSampleBuffers[sampleType];
            
            if (sampleBuf) {
                // Sample-based excitation (real wood transient)
                const src = audioCtx.createBufferSource();
                src.buffer = sampleBuf;
                // Pitch-shift per piece: lighter pieces = higher pitch
                const basePitch = isPlace ? 1.0 : (profile ? profile.liftPitch : 1.3);
                const pieceShift = profile ? ({
                    p: 1.15, n: 1.05, b: 1.02, r: 0.95, q: 0.88, k: 0.82
                })[piece] || 1.0 : 1.0;
                src.playbackRate.setValueAtTime(basePitch * pieceShift, time);
                
                // Envelope for sample
                const sEnv = audioCtx.createGain();
                sEnv.gain.setValueAtTime(vol * 0.75, time);
                sEnv.gain.exponentialRampToValueAtTime(vol * 0.15, time + decay * 0.5);
                sEnv.gain.exponentialRampToValueAtTime(0.0001, time + decay + tail * 0.3);
                
                // Piece-specific filter emphasis
                const emphasis = audioCtx.createBiquadFilter();
                emphasis.type = 'peaking';
                const emphFreq = profile ? profile.toneFreq : pitch;
                emphasis.frequency.setValueAtTime(emphFreq, time);
                emphasis.gain.setValueAtTime(4, time);
                emphasis.Q.setValueAtTime(1.5, time);
                
                src.connect(emphasis);
                emphasis.connect(sEnv);
                sEnv.connect(output);
                src.start(time);
                src.stop(time + decay + tail + 0.1);
            } else {
                // Fallback: original noise burst excitation
                const noiseDur = isPlace ? 0.015 : 0.008;
                const noiseBuf = createNoiseBuffer(noiseDur + 0.02);
                const noise = audioCtx.createBufferSource();
                noise.buffer = noiseBuf;
                const noiseEnv = audioCtx.createGain();
                noiseEnv.gain.setValueAtTime(vol * 0.9, time);
                noiseEnv.gain.exponentialRampToValueAtTime(0.01, time + noiseDur);
                noiseEnv.gain.exponentialRampToValueAtTime(0.0001, time + noiseDur + 0.02);
                const hpFreq = profile ? profile.modes[0].freq * 0.6 : pitch * 0.8;
                const hp = audioCtx.createBiquadFilter();
                hp.type = 'highpass';
                hp.frequency.setValueAtTime(hpFreq, time);
                hp.Q.setValueAtTime(0.5, time);
                noise.connect(hp);
                hp.connect(noiseEnv);
                noiseEnv.connect(output);
                noise.start(time);
                noise.stop(time + noiseDur + 0.05);
            }
            
            // Modal resonance (piece-specific spectrum) - reduced when sample active
            const modes = profile ? profile.modes : [
                { freq: pitch, amp: 1.0, q: sp.woodQ, decay: 1.0 },
            ];
            const modalMix = sampleBuf ? 0.25 : 0.5;  // Less modal when sample provides body
            const totalDur = decay + tail + 0.1;
            const modalNoiseBuf = createNoiseBuffer(totalDur);
            modes.forEach(mode => {
                const src = audioCtx.createBufferSource();
                src.buffer = modalNoiseBuf;
                const bp = audioCtx.createBiquadFilter();
                bp.type = 'bandpass';
                const mFreq = isPlace ? mode.freq : mode.freq * (profile ? profile.liftPitch : 1.3);
                bp.frequency.setValueAtTime(Math.min(mFreq, 16000), time);
                bp.Q.setValueAtTime(mode.q * (sp.woodQ / 6), time);
                const mDecay = decay * mode.decay;
                const mTail = mDecay * 0.6;
                const mGain = audioCtx.createGain();
                mGain.gain.setValueAtTime(vol * mode.amp * modalMix, time);
                mGain.gain.exponentialRampToValueAtTime(vol * mode.amp * 0.02, time + mDecay);
                mGain.gain.exponentialRampToValueAtTime(0.0001, time + mDecay + mTail);
                src.connect(bp);
                bp.connect(mGain);
                mGain.connect(output);
                src.start(time);
                src.stop(time + mDecay + mTail + 0.05);
            });
            
            // Tone: short pitched element - reduced when sample active
            const tFreq = profile ? profile.toneFreq : pitch;
            const osc = audioCtx.createOscillator();
            osc.type = 'triangle';
            osc.frequency.setValueAtTime(isPlace ? tFreq : tFreq * 1.2, time);
            osc.frequency.exponentialRampToValueAtTime(tFreq * 0.88, time + decay + tail);
            const toneVol = sampleBuf ? 0.12 : 0.25;
            const toneGain = audioCtx.createGain();
            toneGain.gain.setValueAtTime(vol * toneVol, time);
            toneGain.gain.exponentialRampToValueAtTime(vol * 0.01, time + decay * 0.8);
            toneGain.gain.exponentialRampToValueAtTime(0.0001, time + decay + tail);
            const toneLp = audioCtx.createBiquadFilter();
            toneLp.type = 'lowpass';
            toneLp.frequency.setValueAtTime(tFreq * 3, time);
            toneLp.frequency.exponentialRampToValueAtTime(tFreq * 0.5, time + decay + tail);
            osc.connect(toneLp);
            toneLp.connect(toneGain);
            toneGain.connect(output);
            osc.start(time);
            osc.stop(time + decay + tail + 0.05);
            
            // Body thump (place only)
            if (isPlace) {
                const thFreq = profile ? profile.thumpFreq : pitch * 0.22;
                const thAmp = profile ? profile.thumpAmp : 0.25;
                const thDecay = 0.09 * decayMult;
                const thump = audioCtx.createOscillator();
                thump.type = 'sine';
                thump.frequency.setValueAtTime(thFreq, time);
                thump.frequency.exponentialRampToValueAtTime(thFreq * 0.4, time + thDecay);
                const thumpGain = audioCtx.createGain();
                thumpGain.gain.setValueAtTime(vol * thAmp, time);
                thumpGain.gain.exponentialRampToValueAtTime(vol * thAmp * 0.02, time + thDecay * 0.7);
                thumpGain.gain.exponentialRampToValueAtTime(0.0001, time + thDecay);
                thump.connect(thumpGain);
                thumpGain.connect(output);
                thump.start(time);
                thump.stop(time + thDecay + 0.05);
            }
        }
        
        // =====================================================
        // SLIDE SOUND (wood on wood)
        // =====================================================
        
        function playSlideSound(volume, pitch, time, duration) {
            if (!audioCtx || volume < 0.01 || duration < 0.01) return;
            const output = createSoundOutput(time);
            const slideBuf = createBrownNoiseBuffer(duration + 0.05);
            const slide = audioCtx.createBufferSource();
            slide.buffer = slideBuf;
            const bp = audioCtx.createBiquadFilter();
            bp.type = 'bandpass';
            bp.frequency.setValueAtTime(pitch * 0.6, time);
            bp.frequency.linearRampToValueAtTime(pitch * 1.4, time + duration * 0.4);
            bp.frequency.linearRampToValueAtTime(pitch * 0.8, time + duration);
            bp.Q.setValueAtTime(1.8, time);
            const bp2 = audioCtx.createBiquadFilter();
            bp2.type = 'bandpass';
            bp2.frequency.setValueAtTime(pitch * 2.5, time);
            bp2.Q.setValueAtTime(3, time);
            const slideGain = audioCtx.createGain();
            slideGain.gain.setValueAtTime(0.001, time);
            slideGain.gain.linearRampToValueAtTime(volume, time + 0.008);
            slideGain.gain.setValueAtTime(volume, time + duration * 0.6);
            slideGain.gain.exponentialRampToValueAtTime(0.001, time + duration);
            const slide2 = audioCtx.createBufferSource();
            slide2.buffer = createNoiseBuffer(duration + 0.05);
            const tex = audioCtx.createGain();
            tex.gain.setValueAtTime(volume * 0.25, time + 0.005);
            tex.gain.exponentialRampToValueAtTime(0.001, time + duration);
            slide.connect(bp);
            bp.connect(slideGain);
            slideGain.connect(output);
            slide2.connect(bp2);
            bp2.connect(tex);
            tex.connect(output);
            slide.start(time);
            slide.stop(time + duration + 0.05);
            slide2.start(time);
            slide2.stop(time + duration + 0.05);
        }
        
        // =====================================================
        // CAPTURE CLACK
        // =====================================================
        
        function playCaptureClack(volume, pitch, time) {
            if (!audioCtx) return;
            const output = createSoundOutput(time);
            
            // Use capture sample when available
            const capBuf = woodSampleBuffers['capture'];
            if (capBuf) {
                const src = audioCtx.createBufferSource();
                src.buffer = capBuf;
                // Slight pitch variation based on frequency
                src.playbackRate.setValueAtTime(0.85 + (pitch / 1500) * 0.3, time);
                const env = audioCtx.createGain();
                env.gain.setValueAtTime(volume * 0.9, time);
                env.gain.exponentialRampToValueAtTime(volume * 0.1, time + 0.08);
                env.gain.exponentialRampToValueAtTime(0.0001, time + 0.15);
                src.connect(env);
                env.connect(output);
                src.start(time);
                src.stop(time + 0.2);
            }
            
            // Synthetic clack layer (always plays, blended with sample)
            const noiseBuf = createNoiseBuffer(0.06);
            const noise = audioCtx.createBufferSource();
            noise.buffer = noiseBuf;
            const bp = audioCtx.createBiquadFilter();
            bp.type = 'bandpass';
            bp.frequency.setValueAtTime(pitch * 2.5, time);
            bp.Q.setValueAtTime(4, time);
            const clackVol = capBuf ? 0.35 : 0.8;
            const nGain = audioCtx.createGain();
            nGain.gain.setValueAtTime(volume * clackVol, time);
            nGain.gain.exponentialRampToValueAtTime(0.001, time + 0.04);
            noise.connect(bp);
            bp.connect(nGain);
            nGain.connect(output);
            const clack = audioCtx.createOscillator();
            clack.type = 'triangle';
            clack.frequency.setValueAtTime(pitch * 1.6, time);
            clack.frequency.exponentialRampToValueAtTime(pitch * 0.5, time + 0.05);
            const cGain = audioCtx.createGain();
            const clackTriVol = capBuf ? 0.15 : 0.35;
            cGain.gain.setValueAtTime(volume * clackTriVol, time);
            cGain.gain.exponentialRampToValueAtTime(0.001, time + 0.07);
            clack.connect(cGain);
            cGain.connect(output);
            noise.start(time);
            clack.start(time);
            noise.stop(time + 0.08);
            clack.stop(time + 0.1);
        }
        
        // =====================================================
        // MOVE DISTANCE (with diagonal sqrt(2) support)
        // =====================================================
        
        function getMoveDistance(from, to, pieceType) {
            const fileFrom = from.charCodeAt(0) - 97;
            const rankFrom = parseInt(from[1]) - 1;
            const fileTo = to.charCodeAt(0) - 97;
            const rankTo = parseInt(to[1]) - 1;
            if (pieceType === 'n') return 2.24; // sqrt(5)
            const df = Math.abs(fileTo - fileFrom);
            const dr = Math.abs(rankTo - rankFrom);
            const fields = Math.max(df, dr);
            // Diagonal moves: effective distance per field is sqrt(2)
            const isDiagonal = df > 0 && dr > 0;
            return isDiagonal ? fields * Math.SQRT2 : fields;
        }
        
        // =====================================================
        // =====================================================
        // PLAY MOVE SOUND (main API - called by game logic)
        // options: { flags: string, promotion: string }
        // =====================================================
        
        function playMoveSound(piece, from, to, captured, options) {
            if (!g_soundEnabled) return;
            initAudio();
            
            const profile = PIECE_PROFILES[piece];
            if (!profile) return;
            const volume = profile.volume;
            const medianFreq = profile.toneFreq;
            const distance = getMoveDistance(from, to, piece);
            const now = audioCtx.currentTime;
            const slideVol = SOUND_PARAMS.slideVol;
            const ds = SOUND_PARAMS.durationScale; // 1.2 = 20% longer
            const flags = options?.flags || '';
            const promotion = options?.promotion;
            
            // ---- CASTLING ----
            // King move (dist 2) + short pause + Rook move (dist 2), both with slide
            if (flags.includes('k') || flags.includes('q')) {
                const kingProfile = PIECE_PROFILES['k'];
                const rookProfile = PIECE_PROFILES['r'];
                const kv = kingProfile.volume;
                const kf = kingProfile.toneFreq;
                const rv = rookProfile.volume;
                const rf = rookProfile.toneFreq;
                
                // King: lift - slide - place (distance 2)
                const kingPause = (0.055 + 1 * 0.015) * ds;
                playWoodClick(kv * 0.5, kf, now, false, 'k');
                if (slideVol > 0.01) {
                    playSlideSound(kv * slideVol, kf, now + 0.015 * ds, kingPause * 0.85);
                }
                playWoodClick(kv, kf, now + kingPause, true, 'k');
                
                // Short pause between King and Rook
                const gap = 0.12 * ds;
                
                // Rook: lift - slide - place (distance 2)
                const rookStart = now + kingPause + gap;
                const rookPause = (0.055 + 1 * 0.015) * ds;
                playWoodClick(rv * 0.5, rf, rookStart, false, 'r');
                if (slideVol > 0.01) {
                    playSlideSound(rv * slideVol, rf, rookStart + 0.015 * ds, rookPause * 0.85);
                }
                playWoodClick(rv, rf, rookStart + rookPause, true, 'r');
                return;
            }
            
            // ---- NORMAL MOVE ----
            // Pause between lift and place (scaled 20% longer)
            const basePause = 0.055 * ds;
            const pause = (piece === 'n')
                ? 0.16 * ds
                : basePause + (distance - 1) * 0.015 * ds;
            
            if (piece === 'n') {
                // Knight: jump character
                playWoodClick(volume * 0.55, medianFreq, now, false, piece);
                playWoodClick(volume, medianFreq, now + pause, true, piece);
                playWoodClick(volume * 0.1, medianFreq, now + pause + 0.05 * ds, true, piece);
            } else {
                // All others: lift - [slide] - place
                playWoodClick(volume * 0.5, medianFreq, now, false, piece);
                const fieldDist = Math.max(Math.abs(from.charCodeAt(0) - to.charCodeAt(0)),
                    Math.abs(parseInt(from[1]) - parseInt(to[1])));
                if (slideVol > 0.01 && fieldDist > 1) {
                    playSlideSound(volume * slideVol, medianFreq, now + 0.015 * ds, pause * 0.85);
                }
                playWoodClick(volume, medianFreq, now + pause, true, piece);
            }
            
            // Capture sound
            if (captured) {
                const capProfile = PIECE_PROFILES[captured];
                if (capProfile) {
                    const cv = capProfile.volume * 0.7;
                    const cp = capProfile.toneFreq;
                    playCaptureClack(cv, cp, now + pause + 0.02 * ds);
                    playWoodClick(cv * 0.3, cp, now + pause + 0.10 * ds, false, captured);
                    playWoodClick(cv * 0.45, cp, now + pause + 0.15 * ds, true, captured);
                }
            }
            
            // ---- PROMOTION ----
            // After pawn move: short pause, then promoted piece sound (distance 1)
            if (promotion && piece === 'p') {
                const promProfile = PIECE_PROFILES[promotion];
                if (promProfile) {
                    const promDelay = pause + 0.14 * ds;
                    const pv = promProfile.volume;
                    const pf = promProfile.toneFreq;
                    const promPause = 0.055 * ds; // distance-1 pause
                    playWoodClick(pv * 0.5, pf, now + promDelay, false, promotion);
                    playWoodClick(pv, pf, now + promDelay + promPause, true, promotion);
                }
            }
        }

// ═══════════════════════════════════════════════════════════════════════════
// PIECE / SQUARE HELPERS (bridge between fahriengine.js's board format
// and the SVG piece set + sound engine below)
// ═══════════════════════════════════════════════════════════════════════════

// Is it currently the human player's turn to move?
function IsPlayersTurn() {
    return !((g_playerWhite && g_toMove === 0) || (!g_playerWhite && g_toMove !== 0));
}

// Raw piece value at a UI-space square (0-7,0-7), respecting board orientation
function GetPieceAtUI(uiX, uiY) {
    var ix = g_playerWhite ? uiX : 7 - uiX;
    var iy = g_playerWhite ? uiY : 7 - uiY;
    return g_board[((iy + 2) * 0x10) + ix + 4];
}

// "wK"/"bP"/... key into PIECE_SVG for a raw piece value
function GetPieceSvgKey(piece) {
    if (!piece) return null;
    var t;
    switch (piece & 0x7) {
        case piecePawn:   t = 'P'; break;
        case pieceKnight: t = 'N'; break;
        case pieceBishop: t = 'B'; break;
        case pieceRook:   t = 'R'; break;
        case pieceQueen:  t = 'Q'; break;
        case pieceKing:   t = 'K'; break;
        default: return null;
    }
    return ((piece & 0x8) ? 'w' : 'b') + t;
}

// 'p'/'n'/'b'/'r'/'q'/'k' letter used by the sound engine
function GetPieceSoundLetter(piece) {
    if (!piece) return null;
    switch (piece & 0x7) {
        case piecePawn:   return 'p';
        case pieceKnight: return 'n';
        case pieceBishop: return 'b';
        case pieceRook:   return 'r';
        case pieceQueen:  return 'q';
        case pieceKing:   return 'k';
    }
    return null;
}

// Convert fahriengine's internal (x,y) move coordinates to algebraic notation
function SquareToAlgebraic(x, y) {
    return 'abcdefgh'[x] + (8 - y);
}

function ClearSelectionHighlight() {
    if (!g_uiBoard) return;
    for (var i = 0; i < g_uiBoard.length; i++) {
        if (g_uiBoard[i]) g_uiBoard[i].classList.remove('selected');
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// SOUND HOOK — bridges a fahriengine move int to playMoveSound()
// ═══════════════════════════════════════════════════════════════════════════

function PlayMoveSoundForMove(move, movingPieceRaw, capturedPieceRaw, isEP) {
    var pieceLetter = GetPieceSoundLetter(movingPieceRaw);
    if (!pieceLetter) return;

    var fromX = (move & 0xF) - 4;
    var fromY = ((move >> 4) & 0xF) - 2;
    var toX   = ((move >> 8) & 0xF) - 4;
    var toY   = ((move >> 12) & 0xF) - 2;

    var fromAlg = SquareToAlgebraic(fromX, fromY);
    var toAlg   = SquareToAlgebraic(toX, toY);

    var capturedLetter = null;
    if (isEP) {
        capturedLetter = 'p';
    } else if (capturedPieceRaw) {
        capturedLetter = GetPieceSoundLetter(capturedPieceRaw);
    }

    var flags = '';
    if (move & moveflagCastleKing)  flags += 'k';
    if (move & moveflagCastleQueen) flags += 'q';

    try {
        playMoveSound(pieceLetter, fromAlg, toAlg, capturedLetter, { flags: flags });
    } catch (e) {
        // Sound is a nice-to-have; never let it break the game
        console.warn('playMoveSound failed:', e);
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// MOVE EXECUTION — same validation/apply logic the original dropPiece used,
// just refactored to take explicit UI-space {x,y} squares.
// ═══════════════════════════════════════════════════════════════════════════

function TryMakeMove(fromUI, toUI) {
    var fromX = fromUI.x, fromY = fromUI.y, toX = toUI.x, toY = toUI.y;
    if (!g_playerWhite) {
        fromX = 7 - fromX; fromY = 7 - fromY;
        toX   = 7 - toX;   toY   = 7 - toY;
    }

    var moves = GenerateValidMoves();
    var move = null;
    for (var i = 0; i < moves.length; i++) {
        if ((moves[i] & 0xFF) === MakeSquare(fromY, fromX) &&
            ((moves[i] >> 8) & 0xFF) === MakeSquare(toY, toX)) {
            move = moves[i];
        }
    }
    if (move == null) return false;

    var movingPiece   = g_board[MakeSquare(fromY, fromX)];
    var capturedPiece = g_board[MakeSquare(toY, toX)];
    var isEP = !!(move & moveflagEPC);

    UpdatePgnTextBox(move);
    if (InitializeBackgroundEngine()) {
        g_backgroundEngine.postMessage(FormatMove(move));
    }
    g_allMoves[g_allMoves.length] = move;
    MakeMove(move);
    UpdateFromMove(move);

    PlayMoveSoundForMove(move, movingPiece, capturedPiece, isEP);
    RefreshEvalBar();

    var fenBox = document.getElementById("FenTextBox");
    if (fenBox) fenBox.value = GetFen();

    if (!CheckGameOver()) {
        setTimeout("SearchAndRedraw()", 0);
    }

    return true;
}

// All legal destination squares (UI-space) for the piece sitting on fromUI
function GetLegalTargetsForSquare(fromUI) {
    var fromX = fromUI.x, fromY = fromUI.y;
    if (!g_playerWhite) { fromX = 7 - fromX; fromY = 7 - fromY; }

    var fromSq = MakeSquare(fromY, fromX);
    var moves = GenerateValidMoves();
    var targets = [];
    var seen = {};

    for (var i = 0; i < moves.length; i++) {
        if ((moves[i] & 0xFF) !== fromSq) continue;
        var toSq = (moves[i] >> 8) & 0xFF;
        var toX = (toSq & 0xF) - 4;
        var toY = ((toSq >> 4) & 0xF) - 2;
        var uiX = toX, uiY = toY;
        if (!g_playerWhite) { uiX = 7 - uiX; uiY = 7 - uiY; }
        var key = uiX + ',' + uiY;
        if (!seen[key]) {
            seen[key] = true;
            targets.push({ x: uiX, y: uiY });
        }
    }
    return targets;
}

// ═══════════════════════════════════════════════════════════════════════════
// SELECTION STATE HELPERS
// ═══════════════════════════════════════════════════════════════════════════

function SetSelection(uiX, uiY) {
    g_selectedSquare = { x: uiX, y: uiY };
    g_legalTargets = GetLegalTargetsForSquare(g_selectedSquare);
    RedrawPieces();
}

function ClearSelection() {
    g_selectedSquare = null;
    g_legalTargets = [];
    RedrawPieces();
}

// ═══════════════════════════════════════════════════════════════════════════
// GHOST PIECE (floating SVG that follows the cursor / finger while dragging)
// ═══════════════════════════════════════════════════════════════════════════

function CreateGhostPiece(pieceKey, clientX, clientY, isTouch) {
    var el = document.createElement('div');
    el.className = 'piece-ghost';
    el.innerHTML = PIECE_SVG[pieceKey];
    var size = Math.round(g_cellSize * 1.18);
    el.style.width  = size + 'px';
    el.style.height = size + 'px';
    el.style.left = clientX + 'px';
    el.style.top  = clientY + 'px';
    if (isTouch) el.style.transform = 'translate(-50%,-135%)';
    document.body.appendChild(el);
    return el;
}

// ═══════════════════════════════════════════════════════════════════════════
// POINTER-BASED DRAG & DROP (unified mouse + touch + pen, chess.com/lichess
// style: press to lift & select with move-dots, drag to follow, drop to move)
// ═══════════════════════════════════════════════════════════════════════════

var g_activeDrag = null; // non-null while a press/drag interaction is in progress

function OnSquarePointerDown(e, uiX, uiY) {
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    e.preventDefault();
    if (g_activeDrag) return; // ignore a second simultaneous pointer

    var piece = GetPieceAtUI(uiX, uiY);
    var isOwn = piece && (((piece & 0x8) !== 0) === g_playerWhite);

    // Pressing the already-selected piece again — allow re-drag; a plain
    // release-in-place (no movement) will toggle the selection off.
    if (g_selectedSquare && g_selectedSquare.x === uiX && g_selectedSquare.y === uiY) {
        if (isOwn && IsPlayersTurn()) {
            StartDrag(e, uiX, uiY, piece, true);
        }
        return;
    }

    // Something else is selected — try moving there first
    if (g_selectedSquare) {
        var from = g_selectedSquare;
        var didMove = TryMakeMove(from, { x: uiX, y: uiY });
        if (didMove) { ClearSelection(); return; }

        if (isOwn && IsPlayersTurn()) {
            SetSelection(uiX, uiY);
            StartDrag(e, uiX, uiY, piece, false);
        } else {
            ClearSelection();
        }
        return;
    }

    // Nothing selected yet — select this piece if it's ours
    if (isOwn && IsPlayersTurn()) {
        SetSelection(uiX, uiY);
        StartDrag(e, uiX, uiY, piece, false);
    }
}

function StartDrag(e, uiX, uiY, piece, wasAlreadySelected) {
    var pieceKey = GetPieceSvgKey(piece);
    var isTouch = (e.pointerType === 'touch' || e.pointerType === 'pen');
    var td = g_uiBoard[uiY * 8 + uiX];
    var pieceDivEl = td ? td.querySelector('.chess-piece') : null;
    var pointerId = e.pointerId;

    var startX = e.clientX, startY = e.clientY;
    var moved = false;
    var ghostEl = null;

    g_activeDrag = { pointerId: pointerId };

    function ensureGhost(x, y) {
        if (!ghostEl) {
            if (pieceDivEl) pieceDivEl.classList.add('is-dragging-source');
            ghostEl = CreateGhostPiece(pieceKey, x, y, isTouch);
        } else {
            ghostEl.style.left = x + 'px';
            ghostEl.style.top  = y + 'px';
        }
    }

    function onMove(ev) {
        if (ev.pointerId !== pointerId) return;
        var dx = ev.clientX - startX, dy = ev.clientY - startY;
        if (!moved && (dx * dx + dy * dy) < 9) return; // ~3px dead-zone, avoids flicker on plain taps
        moved = true;
        ensureGhost(ev.clientX, ev.clientY);
    }

    function cleanup() {
        document.removeEventListener('pointermove', onMove);
        document.removeEventListener('pointerup', onUp);
        document.removeEventListener('pointercancel', onCancel);
        if (ghostEl) { ghostEl.remove(); ghostEl = null; }
        if (pieceDivEl) pieceDivEl.classList.remove('is-dragging-source');
        g_activeDrag = null;
    }

    function onUp(ev) {
        if (ev.pointerId !== pointerId) return;
        cleanup();

        var targetEl = document.elementFromPoint(ev.clientX, ev.clientY);
        var squareTd = targetEl ? targetEl.closest('.board-td') : null;

        if (!squareTd) {
            RedrawPieces();
            return;
        }

        var tx = parseInt(squareTd.dataset.uiX, 10);
        var ty = parseInt(squareTd.dataset.uiY, 10);

        if (tx === uiX && ty === uiY) {
            if (!moved && wasAlreadySelected) {
                ClearSelection(); // plain second tap on the same piece -> deselect
            } else {
                RedrawPieces(); // keep current selection + dots
            }
            return;
        }

        var didMove = TryMakeMove({ x: uiX, y: uiY }, { x: tx, y: ty });
        if (didMove) {
            ClearSelection();
            return;
        }

        var destPiece = GetPieceAtUI(tx, ty);
        if (destPiece && ((destPiece & 0x8) !== 0) === g_playerWhite) {
            SetSelection(tx, ty);
        } else {
            ClearSelection();
        }
    }

    function onCancel(ev) {
        if (ev.pointerId !== pointerId) return;
        cleanup();
        RedrawPieces();
    }

    document.addEventListener('pointermove', onMove);
    document.addEventListener('pointerup', onUp);
    document.addEventListener('pointercancel', onCancel);
}

// ═══════════════════════════════════════════════════════════════════════════
// BOARD RENDERING (board squares themselves are untouched — only piece
// rendering + interaction wiring changes here)
// ═══════════════════════════════════════════════════════════════════════════

function UpdateFromMove(move) {
    ClearSelectionHighlight();

    var fromX = (move & 0xF) - 4;
    var fromY = ((move >> 4) & 0xF) - 2;
    var toX = ((move >> 8) & 0xF) - 4;
    var toY = ((move >> 12) & 0xF) - 2;

    if (!g_playerWhite) {
        fromY = 7 - fromY;
        toY = 7 - toY;
        fromX = 7 - fromX;
        toX = 7 - toX;
    }

    if ((move & moveflagCastleKing) ||
        (move & moveflagCastleQueen) ||
        (move & moveflagEPC) ||
        (move & moveflagPromotion)) {
        RedrawPieces();
    } else {
        var fromSquare = g_uiBoard[fromY * 8 + fromX];
        var toSquare = g_uiBoard[toY * 8 + toX];
        toSquare.innerHTML = '';
        while (fromSquare.firstChild) {
            toSquare.appendChild(fromSquare.firstChild);
        }
    }
}

function RedrawPieces() {
    for (var y = 0; y < 8; ++y) {
        for (var x = 0; x < 8; ++x) {
            var td = g_uiBoard[y * 8 + x];
            td.innerHTML = '';
            td.classList.remove('selected');

            var pieceY = g_playerWhite ? y : 7 - y;
            var pieceX = g_playerWhite ? x : 7 - x;
            var piece = g_board[((pieceY + 2) * 0x10) + pieceX + 4];
            var pieceKey = GetPieceSvgKey(piece);

            if (pieceKey) {
                var pieceDiv = document.createElement('div');
                pieceDiv.className = 'chess-piece';
                pieceDiv.innerHTML = PIECE_SVG[pieceKey];
                td.appendChild(pieceDiv);
            }
        }
    }

    if (g_selectedSquare) {
        var selTd = g_uiBoard[g_selectedSquare.y * 8 + g_selectedSquare.x];
        if (selTd) selTd.classList.add('selected');

        for (var i = 0; i < g_legalTargets.length; i++) {
            var t = g_legalTargets[i];
            var targetTd = g_uiBoard[t.y * 8 + t.x];
            if (!targetTd) continue;
            var hasPieceThere = !!GetPieceAtUI(t.x, t.y);
            var dot = document.createElement('div');
            dot.className = hasPieceThere ? 'move-hint move-hint-capture' : 'move-hint';
            targetTd.appendChild(dot);
        }
    }
}

function RedrawBoard() {
    RecalcCellSize();
    var div = $("#board")[0];

    var table = document.createElement("table");
    table.cellPadding = "0px";
    table.cellSpacing = "0px";
    $(table).addClass('no-highlight');

    var tbody = document.createElement("tbody");
    g_uiBoard = [];

    for (var y = 0; y < 8; ++y) {
        var tr = document.createElement("tr");
        for (var x = 0; x < 8; ++x) {
            var td = document.createElement("td");
            td.style.width  = g_cellSize + "px";
            td.style.height = g_cellSize + "px";
            var isDark = ((y ^ x) & 1);
            td.className = (isDark ? 'board-dark' : 'board-light') + ' board-td';
            td.style.backgroundColor = isDark ? "#B58863" : "#F0D9B5";
            td.dataset.uiX = x;
            td.dataset.uiY = y;

            (function (ux, uy) {
                td.addEventListener('pointerdown', function (e) { OnSquarePointerDown(e, ux, uy); });
            })(x, y);

            tr.appendChild(td);
            g_uiBoard[y * 8 + x] = td;
        }
        tbody.appendChild(tr);
    }

    table.appendChild(tbody);
    RedrawPieces();
    $(div).empty();
    div.appendChild(table);

    var evalBarEl = document.getElementById('evalBarContainer');
    if (evalBarEl) evalBarEl.style.height = (g_cellSize * 8) + 'px';

    g_changingFen = true;
    document.getElementById("FenTextBox").value = GetFen();
    g_changingFen = false;
}
